# YakYak 1.2.0 - Tradução [PT-BR]
O YakYak é um cliente de conversação para o Google Hangouts. 
#
Página oficial: https://github.com/yakyak/yakyak
#
Está é uma tradução do YakYak 1.2.0 para Português-BR.

# Instalação:
Faça o download do YakYak 1.2.0 (Linux x64) em: https://github.com/yakyak/yakyak/releases/download/v1.2.0/yakyak-linux-x64.zip
#
Copie o conteúdo da pasta "tradução" para a pasta "app" dentro do YakYak (já instalado).

# Exemplo:
Minha pasta do YakYak está localizada em: 
#
$ /usr/lib/yakyak/
#
Então colarei o conteúdo em:
#
$ /usr/lib/yakyak/app/
