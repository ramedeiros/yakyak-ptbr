(function() {
  module.exports = view(function(viewstate) {
    return div(function() {
      return link({
        rel: "stylesheet",
        href: viewstate.theme + ".css"
      });
    });
  });

}).call(this);

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInVpL3ZpZXdzL3RoZW1lLmNvZmZlZSJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUFBLE1BQU0sQ0FBQyxPQUFQLEdBQWlCLElBQUEsQ0FBSyxTQUFDLFNBQUQ7V0FDbEIsR0FBQSxDQUFJLFNBQUE7YUFDRixJQUFBLENBQUs7UUFBQSxHQUFBLEVBQUksWUFBSjtRQUFrQixJQUFBLEVBQVMsU0FBUyxDQUFDLEtBQVgsR0FBaUIsTUFBM0M7T0FBTDtJQURFLENBQUo7RUFEa0IsQ0FBTDtBQUFqQiIsImZpbGUiOiJ1aS92aWV3cy90aGVtZS5qcyIsInNvdXJjZVJvb3QiOiIvc291cmNlLyIsInNvdXJjZXNDb250ZW50IjpbIm1vZHVsZS5leHBvcnRzID0gdmlldyAodmlld3N0YXRlKSAtPlxuICAgIGRpdiAtPlxuICAgICAgbGluayByZWw6XCJzdHlsZXNoZWV0XCIsIGhyZWY6IFwiI3t2aWV3c3RhdGUudGhlbWV9LmNzc1wiXG4iXX0=
